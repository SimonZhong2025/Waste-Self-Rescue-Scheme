#include <stdio.h>
#include <string.h>

int main()
{
   char a[110];
   scanf("%s", a);
   int len = strlen(a);

   printf("%d\n", len);
   for (int i = 0; i < len; i ++ )
      printf("%d\n", a[i] - 'a' + 1);
   
   return 0;
}